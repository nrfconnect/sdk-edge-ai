/*********************************************************************************
 * Auto-generated nrf Axon compiled neural network model header file.
 * Model Name: ei_model_nrf_accel_sim_62
 * Axon Neural Network Compiler Version: 2.0.1
 *********************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
#include <stdalign.h>
#include "drivers/axon/nrf_axon_nn_infer.h"

#define NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_IL_BUFFER_USED 36
#define NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_PSUM_BUFFER_USED 0
static_assert(NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_IL_BUFFER_USED <= (NRF_AXON_INTERLAYER_BUFFER_SIZE), "nrf_axon_interlayer_buffer TOO SMALL!!!!\n");
static_assert(NRF_AXON_VERSION >= 0x00010501, "MODEL REQUIRES FEATURES NOT SUPPORTED BY THIS DRIVER VERSION!!! UPGRADE THE AXON DRIVER!!!");

const char* labels_ei_model_nrf_accel_sim_62[] = {
"IDLE",
"SINE",
"TRIANGLE",
};

// size of axon_model_const_ei_model_nrf_accel_sim_62: 1024
const static struct {
	int8_t l00_weights[660];
	int32_t l00_biasp[20];
	int8_t l01_weights[200];
	int32_t l01_biasp[10];
	int8_t l02_weights[30];
	int32_t l02_biasp[3];

} axon_model_const_ei_model_nrf_accel_sim_62 = {
	.l00_weights = {59,-4,43,19,6,11,6,-15,8,69,-50,71,-21,31,-5,20,6,16,-11,-11,114,-52,78,11,33,14,-11,-11,-16,-20,5,91,-37,36,-8,54,3,-7,4,7,7,10,105,-74,71,6,47,14,-12,18,11,23,-14,88,-59,77,0,56,11,-4,16,-5,-17,-4,102,-41,33,6,-20,-16,10,-12,14,19,22,-2,58,20,-30,-4,-13,16,7,13,0,10,17,51,31,-30,-9,-6,22,11,-12,-18,-11,17,88,-32,22,-49,13,-2,13,-2,22,11,-90,-31,4,19,-25,10,-5,-17,-11,8,14,-88,-42,-28,-2,-25,12,-16,13,19,15,-10,-64,-30,78,0,49,-14,-18,-17,19,-5,-11,101,-58,66,-18,35,-16,12,13,15,-2,-5,93,-27,54,2,46,1,16,15,-21,-18,10,70,-32,-11,9,2,-1,-8,-18,2,23,-9,8,-21,-13,-22,11,4,0,-21,6,-7,2,-14,-18,-7,-13,18,-6,6,-3,-11,22,-4,2,18,-34,5,-35,-12,-14,-22,-7,16,-8,-76,95,-50,2,-21,9,-4,-9,-12,22,18,-98,97,-55,9,-51,-2,23,-19,18,6,15,-95,97,-28,-22,6,19,20,6,6,9,-7,-57,81,-27,-2,11,-15,-22,-8,-12,-15,21,-67,66,-57,0,-14,22,-6,6,-22,-3,5,-51,91,11,25,-10,-4,-20,14,-3,-13,-2,-18,22,11,14,-32,4,-10,9,-11,22,5,3,34,19,9,-13,15,16,-2,19,-20,13,-35,18,-32,18,-58,-1,-13,14,-21,0,-12,-93,-62,-29,-14,-42,-15,18,-2,13,16,-15,-76,-28,-8,28,-16,15,1,7,-1,10,-10,-78,-60,79,0,41,-22,-18,-9,13,4,-1,84,-73,67,11,19,11,-13,0,0,8,5,64,-42,36,23,57,-4,-11,-7,16,15,-22,56,-75,57,-3,50,-7,-17,-20,23,-9,17,81,-31,84,11,56,-8,10,-9,-8,21,1,88,-52,82,-1,43,9,14,11,23,9,-2,78,-51,-24,-16,-36,-7,14,-20,-14,-22,-18,-56,-50,-36,15,-22,-8,17,3,-8,19,-6,-56,-33,-28,24,-24,-7,2,-11,19,-6,-10,-61,-69,-39,-23,-12,-1,20,22,-19,21,-3,-68,92,-42,3,-15,-4,-16,-23,-4,-18,-8,-100,66,-46,-13,-16,-23,-15,20,-4,2,7,-91,72,13,-19,-12,4,2,-14,-10,8,11,-5,22,-30,-20,22,-22,-9,-20,3,13,-18,7,21,-19,13,-32,-14,-3,-19,18,-6,23,-26,-13,50,27,-29,-21,-21,6,-3,4,8,52,-33,59,-4,1,11,18,4,10,8,13,26,-12,31,19,-4,0,-10,-8,-4,-13,6,35,-39,-1,-15,-9,-2,18,-5,-8,-17,8,-21,-21,-8,0,7,-8,8,-18,-11,10,-7,-20,-14,7,-10,9,-8,-4,17,-16,16,8,-1,17,-25,21,-21,16,17,-7,-9,19,8,-79,70,-2,0,-26,-16,-8,-16,6,21,-12,-73,66,-37,26,-59,-18,-12,7,-2,-13,-3,-92,79,-34,2,-15,-22,11,2,-15,-2,-1,-60,86,-26,-15,-41,-17,-12,1,-14,-12,9,-73,123,-27,21,-44,-20,-1,-7,-20,-16,11,-60,91,14,20,-35,-11,-4,-8,7,-3,16,-3,88,29,19,-37,0,-9,-1,-19,-12,6,-37,82,32,-23,-45,1,-15,-10,8,18,-16,-13,127,},
	.l00_biasp = {54303,64573,38939,-47724,52211,-10724,-17367,-1843,11512,-67958,38936,67979,-67303,-29055,-17293,23396,-12879,-16563,-18833,27808,},
	.l01_weights = {7,-18,-13,1,19,3,20,-20,-3,-10,2,1,10,19,10,-16,-2,-6,-13,3,-11,-21,13,13,10,-8,-10,-18,-17,3,-10,-10,12,4,13,17,-9,6,-8,-6,-4,-18,-1,20,-9,-11,-7,4,-8,-2,6,10,-4,-16,-2,-13,16,-18,-19,-15,43,35,50,7,19,16,-36,-18,10,8,42,37,-3,-39,2,14,-2,-9,12,50,-36,-4,4,7,-49,13,72,72,-13,32,9,-4,46,80,10,-12,-11,57,87,39,-17,7,-11,5,-7,-22,-3,10,-26,-11,10,7,-12,8,-5,-17,-9,10,-13,-4,49,35,-7,-26,49,11,-104,-96,-2,-12,27,34,-53,-127,-3,4,11,-20,-47,-2,42,54,25,-2,46,14,-83,-101,28,-17,9,55,-22,-103,-21,20,18,-24,-50,26,37,38,39,20,42,10,-35,-6,12,4,43,28,13,-34,-3,46,-13,22,-4,24,-14,-33,0,10,-8,20,84,61,12,-8,-23,-7,34,74,21,-9,-4,46,52,24,},
	.l01_biasp = {-1075,-4736,-11648,31405,56373,-13330,-38721,-13750,37400,44109,},
	.l02_weights = {16,3,25,-66,39,10,-13,-52,-69,74,15,17,-5,-2,-93,1,115,3,18,-65,-22,-5,29,-2,-2,-20,-127,-30,23,61,},
	.l02_biasp = {-2626,-842,-12847,},
};

extern nrf_axon_result_e nrf_axon_nn_op_extension_softmax(void* , uint16_t , void* );

NRF_AXON_CMD_BUFFER_ALIGN
const NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE cmd_buffer_ei_model_nrf_accel_sim_62[95] = {
// segment 0,length 81,Axon NN
0x1fff0051,0x00000054,
0x02000080,0x00010021,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x00330021,
0x02000090,0x00140021,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l00_weights,0x00330001,
0x050000a0,0x00010014,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l00_biasp,0x00050050,0x00010014,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x00030014,
0x000000bc,0x00000000,
0x040000c8,0x00000000,0x00000000,0x03010000,0x00011703,0x00000205,
0x01000180,0x00000003,0x00000000,
0x010001a4,0x00000000,0x00019fe0,
0x010001c8,0xc0000000,0xc0000000,
0x000000f0,0x00000100,
0x00000080,0x00010014,
0x00000088,0x00330014,
0x01000090,0x000a0014,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l01_weights,
0x030000a0,0x0001000a,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l01_biasp,0x00050028,0x0001000a,
0x000000b4,0x0003000a,
0x000001a8,0x0000accf,
0x000000f0,0x00000100,
0x00000080,0x0001000a,
0x00000088,0x0033000a,
0x01000090,0x0003000a,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l02_weights,
0x050000a0,0x00010003,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l02_biasp,0x0005000c,0x00010003,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)((uint8_t*)(nrf_axon_interlayer_buffer)+0xc),0x0005000c,
0x000000d4,0x00010d05,
0x02000180,0x00000007,0xfffe98ee,0x00016712,
0x010001a8,0x00005b42,0x00000000,
0x020001c8,0x80000000,0x00000000,0x7fffffff,
0x000000f0,0x00000100,
0x0000000,
// segment 1,length 9,CPU(software)
0x2fff0009,0x0000000c,
0x00000001,
(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_nn_op_extension_softmax,0x00000006,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)((uint8_t*)(nrf_axon_interlayer_buffer)+0xc),(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x40000000,0x00010001,0x80160003,0x00000001,
};
#define NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_INPUT_VECTOR_CNT 1
NRF_AXON_MODEL_APP_STORAGE const int8_t *ei_model_nrf_accel_sim_62_input_vector_list[NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_INPUT_VECTOR_CNT];
const nrf_axon_nn_compiled_model_input_s ei_model_nrf_accel_sim_62_inputs[] = {
  {/* 0 */
    .ptr = (int8_t*)nrf_axon_interlayer_buffer,
    .dimensions = {
      .height = 1,
      .width = 33,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 1,
    },
    .quant_mult = 77130828,
    .node_id = -1,
    .stride = 33,
    .quant_round = 19,
    .quant_zp = -128,
  }, /* 0 */
}; /* inputs */

#define NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_PACKED_OUTPUT_SIZE 4

#if NRF_AXON_MODEL_ALLOCATE_PACKED_OUTPUT_BUFFER
NRF_AXON_MODEL_APP_STORAGE uint32_t ei_model_nrf_accel_sim_62_packed_output_buf[NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_PACKED_OUTPUT_SIZE/sizeof(uint32_t)];
#endif
const nrf_axon_compiled_model_output_s ei_model_nrf_accel_sim_62_outputs[] = {
  {
    .ptr = (int8_t*)nrf_axon_interlayer_buffer,
    .packed_buffer_offset = 0,
    .packed_size = 4,
    .dimensions = {
      .height = 1,
      .width = 3,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 1,
    },
    .dequant_mult = 32768,
    .node_id = 3,
    .dequant_round = 23,
    .dequant_zp = -128,
    .stride = 3,
  },
};
const nrf_axon_nn_compiled_model_s model_ei_model_nrf_accel_sim_62 = {
    .compiler_version = 0x00020001,
    .model_name = "ei_model_nrf_accel_sim_62",
    .labels = labels_ei_model_nrf_accel_sim_62,
    .inputs = ei_model_nrf_accel_sim_62_inputs,
    .input_vector_list = ei_model_nrf_accel_sim_62_input_vector_list,
    .input_cnt = 1,

    .interlayer_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_IL_BUFFER_USED,
    .psum_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_PSUM_BUFFER_USED,
    .cmd_buffer_ptr = cmd_buffer_ei_model_nrf_accel_sim_62,

    .model_const_ptr = &axon_model_const_ei_model_nrf_accel_sim_62,
    .model_const_size = sizeof(axon_model_const_ei_model_nrf_accel_sim_62),
    .cmd_buffer_len = 95,
    .persistent_vars = {
      .count = 0,
    },
    .output_cnt = 1,
    .outputs = ei_model_nrf_accel_sim_62_outputs,
#if NRF_AXON_MODEL_ALLOCATE_PACKED_OUTPUT_BUFFER
    .packed_output_buf = (int8_t *)ei_model_nrf_accel_sim_62_packed_output_buf,
#endif
    .min_driver_version_required = 0x00010501,
    .is_layer_model = false,
};
#ifdef __cplusplus
}
#endif
