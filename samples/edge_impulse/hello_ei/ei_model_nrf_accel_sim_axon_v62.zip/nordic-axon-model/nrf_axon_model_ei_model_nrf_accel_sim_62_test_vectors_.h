const int8_t ei_model_nrf_accel_sim_62_test_input_vector_0[1][1][33] = {
{{-125,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,-126,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,-125,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,},},
};
const int8_t ei_model_nrf_accel_sim_62_expected_output_vector_0[1][1][3] = {
{{127,-128,-128,},},
};
#if !AXON_MINIMUM_TEST_VECTORS
const int8_t ei_model_nrf_accel_sim_62_test_input_vector_1[1][1][33] = {
{{-125,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,-126,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,-125,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,},},
};
const int8_t ei_model_nrf_accel_sim_62_expected_output_vector_1[1][1][3] = {
{{127,-128,-128,},},
};
const int8_t ei_model_nrf_accel_sim_62_test_input_vector_2[1][1][33] = {
{{-125,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,-126,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,-126,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,},},
};
const int8_t ei_model_nrf_accel_sim_62_expected_output_vector_2[1][1][3] = {
{{127,-128,-128,},},
};
const int8_t ei_model_nrf_accel_sim_62_test_input_vector_3[1][1][33] = {
{{-125,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,-126,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,-125,-128,-128,-128,-128,-128,-128,-128,-128,-128,-128,},},
};
const int8_t ei_model_nrf_accel_sim_62_expected_output_vector_3[1][1][3] = {
{{127,-128,-128,},},
};
#endif

const int8_t* ei_model_nrf_accel_sim_62_input_test_vectors[] = {
  (int8_t*)ei_model_nrf_accel_sim_62_test_input_vector_0,
#if !AXON_MINIMUM_TEST_VECTORS
  (int8_t*)ei_model_nrf_accel_sim_62_test_input_vector_1,
  (int8_t*)ei_model_nrf_accel_sim_62_test_input_vector_2,
  (int8_t*)ei_model_nrf_accel_sim_62_test_input_vector_3,
#endif
};
const int8_t* ei_model_nrf_accel_sim_62_expected_output_vectors[] = {
  (int8_t*)ei_model_nrf_accel_sim_62_expected_output_vector_0,
#if !AXON_MINIMUM_TEST_VECTORS
  (int8_t*)ei_model_nrf_accel_sim_62_expected_output_vector_1,
  (int8_t*)ei_model_nrf_accel_sim_62_expected_output_vector_2,
  (int8_t*)ei_model_nrf_accel_sim_62_expected_output_vector_3,
#endif
};

#if AXON_LAYER_TEST_VECTORS
#if (AXON_LAYER_TEST_START_LAYER<=1) && (AXON_LAYER_TEST_STOP_LAYER>=0)
const int8_t ei_model_nrf_accel_sim_62_expected_output_vector_0_layer_0[1][1][20] = {
{{-128,-128,-89,-128,-128,-128,-41,-48,-127,-106,-128,-128,-116,-49,-128,-128,-128,-58,-50,-42,},},
};
#endif
#if (AXON_LAYER_TEST_START_LAYER<=2) && (AXON_LAYER_TEST_STOP_LAYER>=1)
const int8_t ei_model_nrf_accel_sim_62_expected_output_vector_0_layer_1[1][1][10] = {
{{-128,-128,-128,-128,79,-128,-128,-128,-128,26,},},
};
#endif
#if (AXON_LAYER_TEST_START_LAYER<=3) && (AXON_LAYER_TEST_STOP_LAYER>=2)
const int32_t ei_model_nrf_accel_sim_62_expected_output_vector_0_layer_2[1][1][3] = {
{{60079,-87308,23650,},},
};
#endif
#if (AXON_LAYER_TEST_START_LAYER<=4) && (AXON_LAYER_TEST_STOP_LAYER>=3)
const int8_t ei_model_nrf_accel_sim_62_expected_output_vector_0_layer_3[1][1][3] = {
{{127,-128,-128,},},
};
#endif
#endif

const int8_t* ei_model_nrf_accel_sim_62_layer_expected_output_vectors[] = {
#if AXON_LAYER_TEST_VECTORS
#if (AXON_LAYER_TEST_START_LAYER<=1) && (AXON_LAYER_TEST_STOP_LAYER>=0)
  (int8_t*)ei_model_nrf_accel_sim_62_expected_output_vector_0_layer_0,
#else
  NULL,
#endif
#if (AXON_LAYER_TEST_START_LAYER<=2) && (AXON_LAYER_TEST_STOP_LAYER>=1)
  (int8_t*)ei_model_nrf_accel_sim_62_expected_output_vector_0_layer_1,
#else
  NULL,
#endif
#if (AXON_LAYER_TEST_START_LAYER<=3) && (AXON_LAYER_TEST_STOP_LAYER>=2)
  (int8_t*)ei_model_nrf_accel_sim_62_expected_output_vector_0_layer_2,
#else
  NULL,
#endif
#if (AXON_LAYER_TEST_START_LAYER<=4) && (AXON_LAYER_TEST_STOP_LAYER>=3)
  (int8_t*)ei_model_nrf_accel_sim_62_expected_output_vector_0_layer_3,
#else
  NULL,
#endif
#else
  NULL,
#endif
};
