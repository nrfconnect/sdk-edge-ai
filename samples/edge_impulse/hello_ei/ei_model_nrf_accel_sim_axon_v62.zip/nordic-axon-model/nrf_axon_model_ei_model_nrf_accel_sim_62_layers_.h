/*********************************************************************************
 * Auto-generated nrf Axon compiled neural network model header file.
 * Model Name: ei_model_nrf_accel_sim_62
 * Axon Neural Network Compiler Version: 2.0.1
 *********************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
#include <stdalign.h>
#include "drivers/axon/nrf_axon_nn_infer.h"
#if (AXON_LAYER_TEST_START_LAYER<=0) && (AXON_LAYER_TEST_STOP_LAYER>=0)

NRF_AXON_CMD_BUFFER_ALIGN
const NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE cmd_buffer_ei_model_nrf_accel_sim_62_0[36] = {
// segment 0,length 34,Axon NN
0x1fff0022,0x00000024,
0x02000080,0x00010021,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x00330021,
0x02000090,0x00140021,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l00_weights,0x00330001,
0x050000a0,0x00010014,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l00_biasp,0x00050050,0x00010014,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x00030014,
0x000000bc,0x00000000,
0x040000c8,0x00000000,0x00000000,0x03010000,0x00011703,0x00000205,
0x01000180,0x00000003,0x00000000,
0x010001a4,0x00000000,0x00019fe0,
0x010001c8,0xc0000000,0xc0000000,
0x000000f0,0x00000100,
};
NRF_AXON_MODEL_APP_STORAGE const int8_t *ei_model_nrf_accel_sim_62_input_vector_list_0[1];
const nrf_axon_nn_compiled_model_input_s ei_model_nrf_accel_sim_62_inputs_0[] = {
  {/* 0 */
    .ptr = (int8_t*)nrf_axon_interlayer_buffer,
    .dimensions = {
      .height = 1,
      .width = 33,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 1,
    },
    .quant_mult = 77130828,
    .node_id = -1,
    .stride = 33,
    .quant_round = 19,
    .quant_zp = -128,
  }, /* 0 */
}; /* inputs */

const nrf_axon_compiled_model_output_s ei_model_nrf_accel_sim_62_outputs_0[] = {
  {
    .ptr = (int8_t*)nrf_axon_interlayer_buffer,
    .dimensions = {
      .height = 1,
      .width = 20,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 1,
    },
    .dequant_mult = 65729,
    .node_id = 0,
    .dequant_round = 23,
    .dequant_zp = -128,
    .stride = 20,
  },
};
const nrf_axon_nn_compiled_model_layer_s model_ei_model_nrf_accel_sim_62_0 = {
  .base = {
    .compiler_version = 0x00020001,
    .model_name = "ei_model_nrf_accel_sim_62",
    .labels = labels_ei_model_nrf_accel_sim_62,
    .inputs = ei_model_nrf_accel_sim_62_inputs_0,
    .input_vector_list = ei_model_nrf_accel_sim_62_input_vector_list_0,
    .input_cnt = 1,

    .interlayer_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_IL_BUFFER_USED,
    .psum_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_PSUM_BUFFER_USED,
    .cmd_buffer_ptr = cmd_buffer_ei_model_nrf_accel_sim_62_0,

    .model_const_ptr = &axon_model_const_ei_model_nrf_accel_sim_62,
    .model_const_size = sizeof(axon_model_const_ei_model_nrf_accel_sim_62),
    .cmd_buffer_len = 36,
    .persistent_vars = {
      .count = 0,
    },
    .output_cnt = 1,
    .outputs = ei_model_nrf_accel_sim_62_outputs_0,
#if NRF_AXON_MODEL_ALLOCATE_PACKED_OUTPUT_BUFFER
    .packed_output_buf = (int8_t *)ei_model_nrf_accel_sim_62_packed_output_buf,
#endif
    .min_driver_version_required = 0x00010501,
    .is_layer_model = true,
  },
  .layer_ndx = 0,
};
#endif
#if (AXON_LAYER_TEST_START_LAYER<=1) && (AXON_LAYER_TEST_STOP_LAYER>=1)

NRF_AXON_CMD_BUFFER_ALIGN
const NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE cmd_buffer_ei_model_nrf_accel_sim_62_1[36] = {
// segment 0,length 34,Axon NN
0x1fff0022,0x00000024,
0x02000080,0x00010014,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x00330014,
0x02000090,0x000a0014,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l01_weights,0x00330001,
0x050000a0,0x0001000a,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l01_biasp,0x00050028,0x0001000a,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x0003000a,
0x000000bc,0x00000000,
0x040000c8,0x00000000,0x00000000,0x03010000,0x00011703,0x00000205,
0x01000180,0x00000003,0x00000000,
0x010001a4,0x00000000,0x0000accf,
0x010001c8,0xc0000000,0xc0000000,
0x000000f0,0x00000100,
};
NRF_AXON_MODEL_APP_STORAGE const int8_t *ei_model_nrf_accel_sim_62_input_vector_list_1[1];
const nrf_axon_nn_compiled_model_input_s ei_model_nrf_accel_sim_62_inputs_1[] = {
  {/* 0 */
    .ptr = (int8_t*)nrf_axon_interlayer_buffer,
    .dimensions = {
      .height = 1,
      .width = 20,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 1,
    },
    .node_id = 0,
    .stride = 20,
  }, /* 0 */
}; /* inputs */

const nrf_axon_compiled_model_output_s ei_model_nrf_accel_sim_62_outputs_1[] = {
  {
    .ptr = (int8_t*)nrf_axon_interlayer_buffer,
    .dimensions = {
      .height = 1,
      .width = 10,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 1,
    },
    .dequant_mult = 254328,
    .node_id = 1,
    .dequant_round = 23,
    .dequant_zp = -128,
    .stride = 10,
  },
};
const nrf_axon_nn_compiled_model_layer_s model_ei_model_nrf_accel_sim_62_1 = {
  .base = {
    .compiler_version = 0x00020001,
    .model_name = "ei_model_nrf_accel_sim_62",
    .labels = labels_ei_model_nrf_accel_sim_62,
    .inputs = ei_model_nrf_accel_sim_62_inputs_1,
    .input_vector_list = ei_model_nrf_accel_sim_62_input_vector_list_1,
    .input_cnt = 1,

    .interlayer_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_IL_BUFFER_USED,
    .psum_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_PSUM_BUFFER_USED,
    .cmd_buffer_ptr = cmd_buffer_ei_model_nrf_accel_sim_62_1,

    .model_const_ptr = &axon_model_const_ei_model_nrf_accel_sim_62,
    .model_const_size = sizeof(axon_model_const_ei_model_nrf_accel_sim_62),
    .cmd_buffer_len = 36,
    .persistent_vars = {
      .count = 0,
    },
    .output_cnt = 1,
    .outputs = ei_model_nrf_accel_sim_62_outputs_1,
#if NRF_AXON_MODEL_ALLOCATE_PACKED_OUTPUT_BUFFER
    .packed_output_buf = (int8_t *)ei_model_nrf_accel_sim_62_packed_output_buf,
#endif
    .min_driver_version_required = 0x00010501,
    .is_layer_model = true,
  },
  .layer_ndx = 1,
};
#endif
#if (AXON_LAYER_TEST_START_LAYER<=2) && (AXON_LAYER_TEST_STOP_LAYER>=2)

NRF_AXON_CMD_BUFFER_ALIGN
const NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE cmd_buffer_ei_model_nrf_accel_sim_62_2[39] = {
// segment 0,length 37,Axon NN
0x1fff0025,0x00000028,
0x02000080,0x0001000a,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x0033000a,
0x02000090,0x0003000a,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l02_weights,0x00330001,
0x050000a0,0x00010003,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)axon_model_const_ei_model_nrf_accel_sim_62.l02_biasp,0x0005000c,0x00010003,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)((uint8_t*)(nrf_axon_interlayer_buffer)+0xc),0x0005000c,
0x000000bc,0x00000000,
0x040000c8,0x00000000,0x00000000,0x03010000,0x00010d05,0x00000205,
0x02000180,0x00000007,0xfffe98ee,0x00016712,
0x020001a4,0x00000000,0x00005b42,0x00000000,
0x020001c8,0x80000000,0x00000000,0x7fffffff,
0x000000f0,0x00000100,
};
NRF_AXON_MODEL_APP_STORAGE const int8_t *ei_model_nrf_accel_sim_62_input_vector_list_2[1];
const nrf_axon_nn_compiled_model_input_s ei_model_nrf_accel_sim_62_inputs_2[] = {
  {/* 0 */
    .ptr = (int8_t*)nrf_axon_interlayer_buffer,
    .dimensions = {
      .height = 1,
      .width = 10,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 1,
    },
    .node_id = 1,
    .stride = 10,
  }, /* 0 */
}; /* inputs */

const nrf_axon_compiled_model_output_s ei_model_nrf_accel_sim_62_outputs_2[] = {
  {
    .ptr = (int8_t*)((uint8_t*)(nrf_axon_interlayer_buffer)+0xc),
    .dimensions = {
      .height = 1,
      .width = 3,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 4,
    },
    .dequant_mult = 536870912,
    .node_id = 2,
    .dequant_round = 17,
    .dequant_zp = 0,
    .stride = 12,
  },
};
const nrf_axon_nn_compiled_model_layer_s model_ei_model_nrf_accel_sim_62_2 = {
  .base = {
    .compiler_version = 0x00020001,
    .model_name = "ei_model_nrf_accel_sim_62",
    .labels = labels_ei_model_nrf_accel_sim_62,
    .inputs = ei_model_nrf_accel_sim_62_inputs_2,
    .input_vector_list = ei_model_nrf_accel_sim_62_input_vector_list_2,
    .input_cnt = 1,

    .interlayer_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_IL_BUFFER_USED,
    .psum_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_PSUM_BUFFER_USED,
    .cmd_buffer_ptr = cmd_buffer_ei_model_nrf_accel_sim_62_2,

    .model_const_ptr = &axon_model_const_ei_model_nrf_accel_sim_62,
    .model_const_size = sizeof(axon_model_const_ei_model_nrf_accel_sim_62),
    .cmd_buffer_len = 39,
    .persistent_vars = {
      .count = 0,
    },
    .output_cnt = 1,
    .outputs = ei_model_nrf_accel_sim_62_outputs_2,
#if NRF_AXON_MODEL_ALLOCATE_PACKED_OUTPUT_BUFFER
    .packed_output_buf = (int8_t *)ei_model_nrf_accel_sim_62_packed_output_buf,
#endif
    .min_driver_version_required = 0x00010501,
    .is_layer_model = true,
  },
  .layer_ndx = 2,
};
#endif
#if (AXON_LAYER_TEST_START_LAYER<=3) && (AXON_LAYER_TEST_STOP_LAYER>=3)

NRF_AXON_CMD_BUFFER_ALIGN
const NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE cmd_buffer_ei_model_nrf_accel_sim_62_3[11] = {
// segment 0,length 9,CPU(software)
0x2fff0009,0x0000000c,
0x00000001,
(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_nn_op_extension_softmax,0x00000006,(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)((uint8_t*)(nrf_axon_interlayer_buffer)+0xc),(NRF_AXON_PLATFORM_BITWIDTH_UNSIGNED_TYPE)nrf_axon_interlayer_buffer,0x40000000,0x00010001,0x80160003,0x00000001,
};
NRF_AXON_MODEL_APP_STORAGE const int8_t *ei_model_nrf_accel_sim_62_input_vector_list_3[1];
const nrf_axon_nn_compiled_model_input_s ei_model_nrf_accel_sim_62_inputs_3[] = {
  {/* 0 */
    .ptr = (int8_t*)((uint8_t*)(nrf_axon_interlayer_buffer)+0xc),
    .dimensions = {
      .height = 1,
      .width = 3,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 4,
    },
    .node_id = 2,
    .stride = 12,
  }, /* 0 */
}; /* inputs */

const nrf_axon_compiled_model_output_s ei_model_nrf_accel_sim_62_outputs_3[] = {
  {
    .ptr = (int8_t*)nrf_axon_interlayer_buffer,
    .dimensions = {
      .height = 1,
      .width = 3,
      .channel_cnt = 1,
      .batch_cnt = 1,
      .byte_width = 1,
    },
    .dequant_mult = 32768,
    .node_id = 3,
    .dequant_round = 23,
    .dequant_zp = -128,
    .stride = 3,
  },
};
const nrf_axon_nn_compiled_model_layer_s model_ei_model_nrf_accel_sim_62_3 = {
  .base = {
    .compiler_version = 0x00020001,
    .model_name = "ei_model_nrf_accel_sim_62",
    .labels = labels_ei_model_nrf_accel_sim_62,
    .inputs = ei_model_nrf_accel_sim_62_inputs_3,
    .input_vector_list = ei_model_nrf_accel_sim_62_input_vector_list_3,
    .input_cnt = 1,

    .interlayer_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_IL_BUFFER_USED,
    .psum_buffer_needed = NRF_AXON_MODEL_EI_MODEL_NRF_ACCEL_SIM_62_MAX_PSUM_BUFFER_USED,
    .cmd_buffer_ptr = cmd_buffer_ei_model_nrf_accel_sim_62_3,

    .model_const_ptr = &axon_model_const_ei_model_nrf_accel_sim_62,
    .model_const_size = sizeof(axon_model_const_ei_model_nrf_accel_sim_62),
    .cmd_buffer_len = 11,
    .persistent_vars = {
      .count = 0,
    },
    .output_cnt = 1,
    .outputs = ei_model_nrf_accel_sim_62_outputs_3,
#if NRF_AXON_MODEL_ALLOCATE_PACKED_OUTPUT_BUFFER
    .packed_output_buf = (int8_t *)ei_model_nrf_accel_sim_62_packed_output_buf,
#endif
    .min_driver_version_required = 0x00010501,
    .is_layer_model = true,
  },
  .layer_ndx = 3,
};
#endif
#define MODEL_ei_model_nrf_accel_sim_62_FIRST_COMPUTE_LAYER (0)
nrf_axon_nn_compiled_model_layer_s const *model_ei_model_nrf_accel_sim_62_layer_list[] = {
	#if (AXON_LAYER_TEST_START_LAYER<=0) && (AXON_LAYER_TEST_STOP_LAYER>=0)
  &model_ei_model_nrf_accel_sim_62_0,
#else
  NULL,
#endif
#if (AXON_LAYER_TEST_START_LAYER<=1) && (AXON_LAYER_TEST_STOP_LAYER>=1)
  &model_ei_model_nrf_accel_sim_62_1,
#else
  NULL,
#endif
#if (AXON_LAYER_TEST_START_LAYER<=2) && (AXON_LAYER_TEST_STOP_LAYER>=2)
  &model_ei_model_nrf_accel_sim_62_2,
#else
  NULL,
#endif
#if (AXON_LAYER_TEST_START_LAYER<=3) && (AXON_LAYER_TEST_STOP_LAYER>=3)
  &model_ei_model_nrf_accel_sim_62_3,
#else
  NULL,
#endif

};

#ifdef __cplusplus
}
#endif
